
---
layout: default
title: Carrito
---

<h1>Carrito de Compras</h1>
<div id="cart-items"></div>
<p>Total: $<span id="cart-total">0</span></p>
